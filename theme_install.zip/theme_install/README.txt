Thankyou for downloading the Understrap-Jazz theme!
Version 0.2.1

To Install:
Extract these files into the wp-content/themes directory inside your WordPress installation folder.
Login to WordPress and select the Understrap-Jazz theme.